const messages = {
 
  baseUrl : "http://127.0.0.1:8080",
  noservice : "No service is provided without data starting with (",
  queryAllowed: "Only SELECT or INSERT queries are allowed",
  insert : "INSERT INTO patients (name, dateOfBirth) VALUES ",
  endpoint : "/lab5/api/v1/sql",
  save : "Saved well! info : ",
  error : 'Error: ',
  zero : 'Records: 1 ',
};